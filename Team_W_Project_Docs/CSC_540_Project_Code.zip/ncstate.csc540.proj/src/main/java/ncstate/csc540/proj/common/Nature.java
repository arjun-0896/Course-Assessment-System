package ncstate.csc540.proj.common;

public enum Nature {

	FIXED, PARAMETERIZED
}
