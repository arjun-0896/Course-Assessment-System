package ncstate.csc540.proj.main;

public interface IOption {


}
