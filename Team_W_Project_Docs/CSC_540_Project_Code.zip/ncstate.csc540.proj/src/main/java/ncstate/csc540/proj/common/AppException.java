package ncstate.csc540.proj.common;

/**
 * 
 * @author Team
 * Custom exception
 *
 */
public class AppException extends Throwable {

	public AppException(String errorMessage) {

		super(errorMessage);
	}
}
