package ncstate.csc540.proj.common;

public interface Constants {

	String DATE_FORMAT = "mm/dd/yyyy";

}
