package ncstate.csc540.proj.common;

public enum ROLE {

	TA, INSTRUCTOR, STUDENT

}
