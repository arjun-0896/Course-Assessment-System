package ncstate.csc540.proj.main;

import java.util.List;

public interface Node {

	List<Node> getChildren();
	
}
