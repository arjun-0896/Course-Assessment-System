package ncstate.csc540.proj.ui.executors;

public interface IExecutor {
	
	public boolean execute();

}
